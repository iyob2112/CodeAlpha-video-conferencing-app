import React, { useState, useEffect, useRef, useCallback } from "react";

import { useParams, useNavigate } from "react-router-dom";
import { Loader2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import VideoTile from "@/components/meeting/VideoTile";
import MeetingControls from "@/components/meeting/MeetingControls";
import ChatPanel from "@/components/meeting/ChatPanel";
import ParticipantsPanel from "@/components/meeting/ParticipantsPanel";
import Whiteboard from "@/components/meeting/Whiteboard";
import FilesPanel from "@/components/meeting/FilesPanel";

export default function MeetingRoom() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [meeting, setMeeting] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Media state
  const [localStream, setLocalStream] = useState(null);
  const [screenStream, setScreenStream] = useState(null);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);

  // Panel state
  const [chatOpen, setChatOpen] = useState(false);
  const [participantsOpen, setParticipantsOpen] = useState(false);
  const [whiteboardOpen, setWhiteboardOpen] = useState(false);
  const [filesOpen, setFilesOpen] = useState(false);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [pinnedId, setPinnedId] = useState(null);

  const [participants, setParticipants] = useState([]);

  useEffect(() => {
    initMeeting();
    return () => {
      cleanupMedia();
    };
  }, [id]);

 const initMeeting = async () => {
  
  try {
    const meRes = await fetch("http://192.168.1.5:5000/api/auth/me", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    if (!meRes.ok) throw new Error("Unauthorized");

    const me = await meRes.json();
    setUser(me);

    const meetingRes = await fetch(
      `http://192.168.1.5:5000/api/meetings/${id}`
    );

    const m = await meetingRes.json();

setMeeting(m);
setParticipants((m.participants || []).concat(me.id));

    if (!m) {
      setError("Meeting not found");
      return;
    }

    setMeeting(m);

    // update participants
    await fetch(`http://192.168.1.5:5000/api/meetings/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        participants: [...(m.participants || []), me.id],
        status: "active",
      }),
    });

    // media
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true,
    });

    setLocalStream(stream);
  } catch (err) {
    setError("Failed to join meeting");
  } finally {
    setLoading(false);
  }
};

  const cleanupMedia = () => {
    localStream?.getTracks().forEach((t) => t.stop());
    screenStream?.getTracks().forEach((t) => t.stop());
  };

  const toggleMic = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach((t) => (t.enabled = !t.enabled));
      setIsMicOn(!isMicOn);
    }
  };

  const toggleCamera = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach((t) => (t.enabled = !t.enabled));
      setIsCameraOn(!isCameraOn);
    }
  };

  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      screenStream?.getTracks().forEach((t) => t.stop());
      setScreenStream(null);
      setIsScreenSharing(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({
          video: { width: 1920, height: 1080 },
          audio: true,
        });
        setScreenStream(stream);
        setIsScreenSharing(true);
        stream.getVideoTracks()[0].onended = () => {
          setScreenStream(null);
          setIsScreenSharing(false);
        };
      } catch {
        // User cancelled
      }
    }
  };

  const togglePanel = (panel) => {
    const closers = {
      chat: () => { setChatOpen(!chatOpen); setParticipantsOpen(false); setWhiteboardOpen(false); setFilesOpen(false); if (!chatOpen) setUnreadMessages(0); },
      participants: () => { setParticipantsOpen(!participantsOpen); setChatOpen(false); setWhiteboardOpen(false); setFilesOpen(false); },
      whiteboard: () => { setWhiteboardOpen(!whiteboardOpen); setChatOpen(false); setParticipantsOpen(false); setFilesOpen(false); },
      files: () => { setFilesOpen(!filesOpen); setChatOpen(false); setParticipantsOpen(false); setWhiteboardOpen(false); },
    };
    closers[panel]?.();
  };

  const copyInvite = () => {
    if (meeting?.room_code) {
      navigator.clipboard.writeText(meeting.room_code);
      toast({ title: "Room code copied!", description: `Share "${meeting.room_code}" with others to join.` });
    }
  };
const leaveMeeting = async () => {
  try {
    cleanupMedia();

    const updated = participants.filter(p => p.id !== userId);

    await fetch(`http://192.168.1.5:5000/api/meetings/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        participants: updated,
        status: updated.length === 0 ? "ended" : "active",
      }),
    });

    navigate("/");
  } catch (err) {
    console.error("leaveMeeting failed:", err);
  }
};

  const sidePanelOpen = chatOpen || participantsOpen || whiteboardOpen || filesOpen;

  // const participantsList = [
  //   {
  //     id: user?.id,
  //     isLocal: true,
  //   },
  // ];
  const participantsList = participants.map((p) => ({
    id: p,
    name: p,
    isLocal: p === user?.id,
    // name: user?.full_name || user?.email || "You",
    isMuted: !isMicOn,
    isCameraOff: !isCameraOn,
}));

  if (loading) {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center bg-background gap-3">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Joining meeting...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center bg-background gap-4">
        <AlertCircle className="w-12 h-12 text-destructive" />
        <h2 className="text-lg font-semibold">{error}</h2>
        <Button onClick={() => navigate("/")} variant="secondary">Back to Home</Button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 flex flex-col bg-background">
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-card/60 backdrop-blur-xl border-b border-border">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <h1 className="font-semibold text-sm truncate">{meeting?.title}</h1>
          <span className="hidden sm:inline text-xs text-muted-foreground font-mono bg-secondary px-2 py-0.5 rounded">
            {meeting?.room_code}
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <MeetingTimer />
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Video grid */}
        <div className={`flex-1 p-3 transition-all duration-300 ${sidePanelOpen ? "sm:mr-0" : ""}`}>
          <div className={`grid gap-3 h-full auto-rows-fr ${
            isScreenSharing
              ? "grid-cols-1"
              : participantsList.length <= 1
                ? "grid-cols-1 max-w-2xl mx-auto"
                : participantsList.length <= 4
                  ? "grid-cols-1 sm:grid-cols-2"
                  : "grid-cols-2 sm:grid-cols-3"
          }`}>
            {/* Screen share tile */}
            {isScreenSharing && screenStream && (
              <VideoTile
                stream={screenStream}
                name={user?.full_name || "Your Screen"}
                isLocal
                isScreenShare
                isPinned
              />
            )}
            {/* Local video */}
            <VideoTile
              stream={isCameraOn ? localStream : null}
              name={user?.full_name || user?.email}
              isMuted={!isMicOn}
              isLocal
              isPinned={pinnedId === "local"}
              onPin={() => setPinnedId(pinnedId === "local" ? null : "local")}
            />
          </div>
        </div>

        {/* Side panel */}
        {sidePanelOpen && (
          <div className="w-full sm:w-80 flex-shrink-0">
            {chatOpen && (
              <ChatPanel
                meetingId={id}
                currentUser={user}
                onClose={() => setChatOpen(false)}
                onNewMessage={() => setUnreadMessages((p) => p + 1)}
              />
            )}
            {participantsOpen && (
              <ParticipantsPanel
                participants={participantsList}
                hostId={meeting?.host_id}
                onClose={() => setParticipantsOpen(false)}
              />
            )}
            {whiteboardOpen && (
              <Whiteboard
                meetingId={id}
                currentUser={user}
                onClose={() => setWhiteboardOpen(false)}
              />
            )}
            {filesOpen && (
              <FilesPanel
                meetingId={id}
                currentUser={user}
                onClose={() => setFilesOpen(false)}
              />
            )}
          </div>
        )}
      </div>

      {/* Controls */}
      <MeetingControls
        isMicOn={isMicOn}
        onToggleMic={toggleMic}
        isCameraOn={isCameraOn}
        onToggleCamera={toggleCamera}
        isScreenSharing={isScreenSharing}
        onToggleScreenShare={toggleScreenShare}
        onToggleChat={() => togglePanel("chat")}
        chatOpen={chatOpen}
        unreadMessages={chatOpen ? 0 : unreadMessages}
        onToggleParticipants={() => togglePanel("participants")}
        participantsOpen={participantsOpen}
        participantCount={participantsList.length}
        onToggleWhiteboard={() => togglePanel("whiteboard")}
        whiteboardOpen={whiteboardOpen}
        onToggleFiles={() => togglePanel("files")}
        filesOpen={filesOpen}
        onLeaveMeeting={leaveMeeting}
        onCopyInvite={copyInvite}
      />
    </div>
  );
}

function MeetingTimer() {
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  const pad = (n) => String(n).padStart(2, "0");

  return (
    <span className="font-mono tabular-nums">
      {hrs > 0 && `${pad(hrs)}:`}{pad(mins)}:{pad(secs)}
    </span>
  );
}