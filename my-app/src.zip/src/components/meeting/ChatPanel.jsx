import { useState, useRef, useEffect } from "react";
import { Send, X, FileIcon, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import moment from "moment";

const API = "http://192.168.1.5:5000/api";

export default function ChatPanel({
  meetingId,
  currentUser,
  onClose,
  onNewMessage,
}) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);

  const bottomRef = useRef(null);

  useEffect(() => {
    loadMessages();
  }, [meetingId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const loadMessages = async () => {
    try {
      const res = await fetch(`${API}/messages/${meetingId}`);
      const data = await res.json();
      setMessages(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    setSending(true);

    try {
      const res = await fetch(`${API}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          meeting_id: meetingId,
          sender_name: currentUser?.full_name || "User",
          sender_id: currentUser?.id,
          content: input.trim(),
          type: "text",
        }),
      });

      const msg = await res.json();

      setMessages((prev) => [...prev, msg]);
      setInput("");
      onNewMessage?.();
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSending(true);

    try {
      // upload file
      const formData = new FormData();
      formData.append("file", file);

      const uploadRes = await fetch(`${API}/files/upload`, {
        method: "POST",
        body: formData,
      });

      const uploadData = await uploadRes.json();

      // save message
      const res = await fetch(`${API}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          meeting_id: meetingId,
          sender_name: currentUser?.full_name || "User",
          sender_id: currentUser?.id,
          content: file.name,
          type: "file",
          file_url: uploadData.file_url,
          file_name: file.name,
        }),
      });

      const msg = await res.json();
      setMessages((prev) => [...prev, msg]);
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-card border-l border-border">

      {/* header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h3 className="font-semibold text-sm">Meeting Chat</h3>
        <button onClick={onClose}>
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {loading ? (
          <div className="flex justify-center items-center h-full">
            <Loader2 className="w-5 h-5 animate-spin" />
          </div>
        ) : messages.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground">
            No messages yet
          </p>
        ) : (
          messages.map((msg) => {
            const isMe = msg.sender_id === currentUser?.id;

            return (
              <div
                key={msg._id}
                className={`flex flex-col ${
                  isMe ? "items-end" : "items-start"
                }`}
              >
                <span className="text-[10px] text-muted-foreground mb-1">
                  {isMe ? "You" : msg.sender_name} ·{" "}
                  {moment(msg.createdAt).format("h:mm A")}
                </span>

                {msg.type === "file" ? (
                  <a
                    href={msg.file_url}
                    target="_blank"
                    className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm max-w-[240px] ${
                      isMe
                        ? "bg-primary text-white"
                        : "bg-secondary text-foreground"
                    }`}
                  >
                    <FileIcon className="w-4 h-4" />
                    <span className="truncate">{msg.file_name}</span>
                  </a>
                ) : (
                  <div
                    className={`px-3 py-2 rounded-xl text-sm max-w-[240px] ${
                      isMe
                        ? "bg-primary text-white"
                        : "bg-secondary text-foreground"
                    }`}
                  >
                    {msg.content}
                  </div>
                )}
              </div>
            );
          })
        )}

        <div ref={bottomRef} />
      </div>

      {/* input */}
      <div className="p-3 border-t border-border">
        <div className="flex items-center gap-2">

          <label className="cursor-pointer">
            <FileIcon className="w-4 h-4 text-muted-foreground" />
            <input type="file" hidden onChange={handleFileUpload} />
          </label>

          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Type a message..."
          />

          <Button
            onClick={handleSend}
            disabled={!input.trim() || sending}
            size="sm"
          >
            {sending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}