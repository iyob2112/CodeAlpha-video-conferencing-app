import React, { useRef, useState, useEffect } from "react";
import {
  Pencil,
  Eraser,
  Square,
  Circle,
  Minus,
  Download,
  Trash2,
  X,
} from "lucide-react";

const COLORS = ["#ffffff", "#ef4444", "#3b82f6", "#22c55e", "#eab308"];
const WIDTHS = [2, 4, 6, 8];

export default function Whiteboard({ meetingId, currentUser, onClose }) {
  const canvasRef = useRef(null);

  const [tool, setTool] = useState("pen");
  const [color, setColor] = useState("#ffffff");
  const [lineWidth, setLineWidth] = useState(2);
  const [isDrawing, setIsDrawing] = useState(false);
  const currentPath = useRef([]);

  // init
  useEffect(() => {
    loadStrokes();

    const canvas = canvasRef.current;
    if (canvas) {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;

      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#111827";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
  }, [meetingId]);

  // ---------------- API ----------------

  const getToken = () => localStorage.getItem("token");

  const loadStrokes = async () => {
    try {
      const res = await fetch(
        `http://192.168.1.5:5000/api/whiteboard/${meetingId}`,
        {
          headers: {
            Authorization: `Bearer ${getToken()}`,
          },
        }
      );

      const data = await res.json();
      data.forEach(drawStrokeOnCanvas);
    } catch (err) {
      console.log("Load error:", err);
    }
  };

  const saveStroke = async (stroke) => {
    await fetch("http://192.168.1.5:5000/api/whiteboard", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${getToken()}`,
      },
      body: JSON.stringify(stroke),
    });
  };

  const clearBoard = async () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    ctx.fillStyle = "#111827";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    await fetch(
      `http://192.168.1.5:5000/api/whiteboard/${meetingId}`,
      {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${getToken()}`,
        },
      }
    );
  };

  // ---------------- DRAW ----------------

  const drawStrokeOnCanvas = (stroke) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    const points = stroke.points;

    ctx.strokeStyle =
      stroke.tool === "eraser" ? "#111827" : stroke.color;
    ctx.lineWidth = stroke.width;
    ctx.lineCap = "round";

    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);

    points.forEach((p) => ctx.lineTo(p.x, p.y));
    ctx.stroke();
  };

  const getPos = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();

    const x = e.touches
      ? e.touches[0].clientX - rect.left
      : e.clientX - rect.left;

    const y = e.touches
      ? e.touches[0].clientY - rect.top
      : e.clientY - rect.top;

    return { x, y };
  };

  const startDrawing = (e) => {
    e.preventDefault();
    setIsDrawing(true);

    const pos = getPos(e);
    currentPath.current = [pos];

    const ctx = canvasRef.current.getContext("2d");
    ctx.strokeStyle = tool === "eraser" ? "#111827" : color;
    ctx.lineWidth = tool === "eraser" ? lineWidth * 4 : lineWidth;

    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
  };

  const draw = (e) => {
    if (!isDrawing) return;

    const pos = getPos(e);
    currentPath.current.push(pos);

    const ctx = canvasRef.current.getContext("2d");
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
  };

  const stopDrawing = async () => {
    if (!isDrawing) return;
    setIsDrawing(false);

    if (currentPath.current.length < 2) return;

    const stroke = {
      meetingId,
      points: currentPath.current,
      tool,
      color,
      width: lineWidth,
      authorId: currentUser?.id,
    };

    await saveStroke(stroke);
    currentPath.current = [];
  };

  // ---------------- UI ----------------

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      {/* Top bar */}
      <div className="flex justify-between p-2 border-b border-gray-700">
        <h2 className="text-sm font-semibold">Whiteboard</h2>

        <div className="flex gap-2">
          <button onClick={clearBoard}>
            <Trash2 size={16} />
          </button>
          <button onClick={onClose}>
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Tools */}
      <div className="flex gap-2 p-2 border-b border-gray-700">
        {[Pencil, Eraser, Minus, Square, Circle].map((Icon, i) => (
          <button
            key={i}
            onClick={() =>
              setTool(["pen", "eraser", "line", "rect", "circle"][i])
            }
          >
            <Icon size={16} />
          </button>
        ))}

        {COLORS.map((c) => (
          <div
            key={c}
            onClick={() => setColor(c)}
            className="w-4 h-4 rounded-full cursor-pointer"
            style={{ backgroundColor: c }}
          />
        ))}
      </div>

      {/* Canvas */}
      <div className="flex-1">
        <canvas
          ref={canvasRef}
          className="w-full h-full cursor-crosshair"
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
        />
      </div>
    </div>
  );
}